import React, { useEffect, useState } from "react";
import "./Teacher.css";
import axios from "axios";
import { toast } from "react-toastify";
import { Link, useNavigate, useParams } from "react-router-dom";
import TeacherSidebar from "./TeacherSidebar";

function UpdateStudent_ByTeacher()
{
    const [collapse, setCollapse] = useState(false);
    const [loading, setloading] = useState(false);

    const [name, setname] = useState("")
    const [studentId, setstudentId] = useState("")
    const [studentemail, setstudentemail] = useState("")
    const [phone, setphone] = useState("")
    const [fathername, setfathername] = useState("")
    const [mothername, setmothername] = useState("")
    const [phone2, setphone2] = useState("")

    const navi = useNavigate();


    useEffect(() =>
    {
        document.title = "Update Student"
    }, [])

    const { sid } = useParams()

    useEffect(() =>
    {
        if (sid)
        {
            fetch_student_data()
        }
    }, [sid])

    async function fetch_student_data()
    {
        try
        {
            setloading(true)
            const resp = await axios.get(`${import.meta.env.VITE_API_URL}/api/fetch_student_data_by_teacher/${sid}`);

            if (resp.data.statuscode === 1)
            {
                const student = resp.data.student_data;
                setname(student.name);
                setstudentId(student.studentID)
                setstudentemail(student.email);
                setphone(student.phone);
                setphone2(student.phone2);
                setfathername(student.father);
                setmothername(student.mother);
            }
            else 
            {
                toast.warn(resp.data.msg)
                setteacher(null);
            }
        }
        catch (e)
        {
            toast.error("Error Occured : " + (e.response?.data?.msg || e.message))
        }
        finally
        {
            setloading(false)
        }
    }

    async function UpdateStudentdata(e)
    {
        e.preventDefault()
        try
        {
            setloading(true)
            const student_data = { name, phone, phone2, sid, fathername, mothername }
            const resp = await axios.put(`${import.meta.env.VITE_API_URL}/api/update_student_data_by_teacher`, student_data);

            if (resp.data.statuscode === 1)
            {
                toast.success(resp.data.msg)
                navi("/teacherpanel")
            }
            else 
            {
                toast.warn(resp.data.msg)
            }
        }
        catch (e)
        {
            toast.error("Error Occured " + (e.response?.data?.msg || e.message))
        }
        finally
        {
            setloading(false)
        }

    }


    return (
        <div id="Teacher_page">

            {loading && (
                <div className="overlay">
                    <div>
                        <div className="spinner"></div>
                        <p style={{ color: "white", marginTop: "10px" }}>
                            Please wait...
                        </p>
                    </div>
                </div>
            )}

            <div className="teacher_container">

                <TeacherSidebar collapse={collapse} setCollapse={setCollapse} />

                <div className={`teacher_maincontent ${collapse ? "expand" : ""}`}>
                    <h1 className="hd text-center">Update Student</h1>

                    <form name="updateform" onSubmit={UpdateStudentdata}>
                        <div className="form-container">

                            <div className="form-group">
                                <label>Name</label>
                                <input type="text" placeholder="Enter student name" value={name || ""}
                                    required onChange={(e) => setname(e.target.value)} minLength={3} />
                            </div>

                            <div className="form-group">
                                <label>Student ID</label>
                                <input type="text" disabled placeholder="Enter Student id" value={studentId || ""}
                                    required />
                            </div>

                            <div className="form-group">
                                <label>Email</label>
                                <input type="email" disabled placeholder="Enter student email" value={studentemail || ""}
                                />
                            </div>

                            <div className="form-group">
                                <label>Phone</label>
                                <input type="text" placeholder="Enter phone number" value={phone || ""}
                                    required onChange={(e) => setphone(e.target.value)} minLength={10} maxLength={10} />
                            </div>

                            <div className="form-group">
                                <label>Alternative Phone</label>
                                <input type="text" placeholder="Enter phone number" value={phone2 || ""}
                                    required onChange={(e) => setphone2(e.target.value)} minLength={10} maxLength={10} />
                            </div>

                            <div className="form-group">
                                <label>Father Name</label>
                                <input type="text" placeholder="Enter phone number" value={fathername || ""}
                                    required onChange={(e) => setfathername(e.target.value)} minLength={3} />
                            </div>

                            <div className="form-group">
                                <label>Mother Name</label>
                                <input type="text" placeholder="Enter phone number" value={mothername || ""}
                                    required onChange={(e) => setmothername(e.target.value)} minLength={3} />
                            </div>

                            <button type="submit" className="register-button mt-3" disabled={loading}>
                                {loading ? "Updating Student..." : "Update Student"}
                            </button>

                        </div>
                    </form>

                </div>
            </div>
        </div >
    );
}

export default UpdateStudent_ByTeacher;