import React, { useEffect, useState } from "react";
import "./Teacher.css";
import axios from "axios";
import { toast } from "react-toastify";
import { Link, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import TeacherSidebar from "./TeacherSidebar";

function AddStudent_ByTeacher()
{
    const [collapse, setCollapse] = useState(false);
    const [loading, setloading] = useState(false);
    const navi = useNavigate();
    const { email } = useSelector((state) => state.teacher)


    const [name, setname] = useState("")
    const [studentId, setstudentId] = useState("")
    const [studentemail, setstudentemail] = useState("")
    const [phone, setphone] = useState("")
    const [fathername, setfathername] = useState("")
    const [mothername, setmothername] = useState("")
    const [phone2, setphone2] = useState("")

    useEffect(() =>
    {
        document.title = "Add Student"
    }, [])

    async function addstudent(e)
    {
        e.preventDefault()

        if (phone === phone2) 
        {
            toast.error("Phone Number and Alternative Phone Number cannot be Same")
        }
        else
        {
            const reqdata = { name, studentId, email, studentemail, phone, fathername, mothername, phone2 }
            try 
            {
                setloading(true)
                const resp = await axios.post(`${import.meta.env.VITE_API_URL}/api/add_student_by_teacher`, reqdata)
                if (resp.data.statuscode === 1)
                {
                    toast.success(resp.data.msg)
                    navi("/teacherPanel")
                }
                else
                {
                    toast.error(resp.data.msg)
                }
            }
            catch (e) 
            {
                toast.error("Error Occured : " + (e.response?.data?.msg || e.message))
            }
            finally
            {
                setloading(false)
            }
        }

    }

    return (
        <div id="Teacher_page">

            {loading && (
                <div className="overlay">
                    <div>
                        <div className="spinner"></div>
                        <p style={{ color: "white", marginTop: "10px" }}>
                            Please wait...
                        </p>
                    </div>
                </div>
            )}

            <div className="teacher_container">

                <TeacherSidebar collapse={collapse} setCollapse={setCollapse} />

                <div className={`teacher_maincontent ${collapse ? "expand" : ""}`}>
                    <h1 className="hd text-center">Add Student</h1>

                    <form name="studentform" onSubmit={addstudent}>
                        <div className="student-form">

                            <div className="form-grid">

                                <div className="form-group">
                                    <label>Name</label>
                                    <input type="text" placeholder="Enter student name" required onChange={(e) => setname(e.target.value)} minLength={3} />
                                </div>

                                <div className="form-group">
                                    <label>Student ID</label>
                                    <input type="text" placeholder="Enter student ID" required onChange={(e) => setstudentId(e.target.value)} />
                                </div>

                                <div className="form-group">
                                    <label>Email</label>
                                    <input type="email" placeholder="Enter email" required onChange={(e) => setstudentemail(e.target.value)} />
                                </div>

                                <div className="form-group">
                                    <label>Phone No</label>
                                    <input type="text" placeholder="Enter phone number" required onChange={(e) => setphone(e.target.value)} minLength={10} maxLength={10} />
                                </div>

                                <div className="form-group">
                                    <label>Father Name</label>
                                    <input type="text" placeholder="Enter father name" required onChange={(e) => setfathername(e.target.value)} minLength={3} />
                                </div>

                                <div className="form-group">
                                    <label>Mother Name</label>
                                    <input type="text" placeholder="Enter mother name" required onChange={(e) => setmothername(e.target.value)} minLength={3} />
                                </div>

                                <div className="form-group">
                                    <label>Phone No (2)</label>
                                    <input type="text" placeholder="Enter alternate number" required onChange={(e) => setphone2(e.target.value)} minLength={10} maxLength={10} />
                                </div>

                            </div>

                            <button type="submit" className="register-button mt-3" disabled={loading}>
                                {loading ? "Adding Student..." : "Add Student"}
                            </button>
                        </div>
                    </form>

                </div>
            </div>
        </div >
    );
}

export default AddStudent_ByTeacher;